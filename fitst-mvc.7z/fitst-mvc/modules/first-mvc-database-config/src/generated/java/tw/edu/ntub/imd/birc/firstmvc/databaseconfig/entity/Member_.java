package tw.edu.ntub.imd.birc.firstmvc.databaseconfig.entity;

import java.time.LocalDateTime;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Member.class)
public abstract class Member_ {

	public static volatile SingularAttribute<Member, String> gender;
	public static volatile SingularAttribute<Member, String> name;
	public static volatile SingularAttribute<Member, Boolean> available;
	public static volatile SingularAttribute<Member, String> id;
	public static volatile SingularAttribute<Member, LocalDateTime> transactionTime;

	public static final String GENDER = "gender";
	public static final String NAME = "name";
	public static final String AVAILABLE = "available";
	public static final String ID = "id";
	public static final String TRANSACTION_TIME = "transactionTime";

}

