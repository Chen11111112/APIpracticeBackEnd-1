package tw.edu.ntub.imd.birc.firstmvc.databaseconfig.entity;

import java.time.LocalDateTime;
import javax.annotation.Generated;
import javax.persistence.metamodel.SingularAttribute;
import javax.persistence.metamodel.StaticMetamodel;

@Generated(value = "org.hibernate.jpamodelgen.JPAMetaModelEntityProcessor")
@StaticMetamodel(Score.class)
public abstract class Score_ {

	public static volatile SingularAttribute<Score, String> studentId;
	public static volatile SingularAttribute<Score, Integer> score;
	public static volatile SingularAttribute<Score, Member> memberByStudentId;
	public static volatile SingularAttribute<Score, String> subject;
	public static volatile SingularAttribute<Score, Integer> id;
	public static volatile SingularAttribute<Score, LocalDateTime> transactionTime;

	public static final String STUDENT_ID = "studentId";
	public static final String SCORE = "score";
	public static final String MEMBER_BY_STUDENT_ID = "memberByStudentId";
	public static final String SUBJECT = "subject";
	public static final String ID = "id";
	public static final String TRANSACTION_TIME = "transactionTime";

}

