package tw.edu.ntub.imd.birc.firstmvc.databaseconfig.dao.criteria;

public enum OrderType {
    ASC, DESC
}
