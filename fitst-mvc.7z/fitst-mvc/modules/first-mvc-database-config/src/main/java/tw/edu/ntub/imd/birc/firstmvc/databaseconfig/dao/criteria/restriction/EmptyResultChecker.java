package tw.edu.ntub.imd.birc.firstmvc.databaseconfig.dao.criteria.restriction;

@FunctionalInterface
public interface EmptyResultChecker {
    boolean isEmpty();
}
