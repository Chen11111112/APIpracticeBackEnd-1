package tw.edu.ntub.imd.birc.firstmvc.dto;

public interface CodeEntry {
    String getCode();

    String getValue();
}
