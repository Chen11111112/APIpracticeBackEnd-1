package tw.edu.ntub.imd.birc.firstmvc.service.transformer;

import tw.edu.ntub.imd.birc.firstmvc.bean.ScoreBean;
import tw.edu.ntub.imd.birc.firstmvc.databaseconfig.entity.Score;

public interface ScoreTransformer extends BeanEntityTransformer<ScoreBean, Score> {
}
