package tw.edu.ntub.imd.birc.firstmvc.controller;

import lombok.AllArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import tw.edu.ntub.imd.birc.firstmvc.util.http.ResponseEntityBuilder;
import tw.edu.ntub.imd.birc.firstmvc.util.json.array.ArrayData;
import tw.edu.ntub.imd.birc.firstmvc.util.json.object.ObjectData;

@AllArgsConstructor
@RestController
@RequestMapping(path = "/harry")
public class HarryController {
    @GetMapping(path = "")
    public ResponseEntity<String> searchList(){
        ArrayData arrayData = new ArrayData();
        for (int i = 0; i < 15; i++) {
            ObjectData objectData = arrayData.addObject();
            objectData.add("title","title" + i);
            objectData.add("content","content" + i);
        }
        return ResponseEntityBuilder.success()
                .message("查詢成功")
                .data(arrayData)
                .build();
    }
}
