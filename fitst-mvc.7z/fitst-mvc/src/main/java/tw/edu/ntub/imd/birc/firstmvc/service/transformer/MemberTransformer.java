package tw.edu.ntub.imd.birc.firstmvc.service.transformer;

import tw.edu.ntub.imd.birc.firstmvc.bean.MemberBean;
import tw.edu.ntub.imd.birc.firstmvc.databaseconfig.entity.Member;

public interface MemberTransformer extends BeanEntityTransformer<MemberBean, Member> {
}
