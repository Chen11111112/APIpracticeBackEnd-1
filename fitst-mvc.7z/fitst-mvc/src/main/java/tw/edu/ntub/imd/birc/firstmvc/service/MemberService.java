package tw.edu.ntub.imd.birc.firstmvc.service;

import tw.edu.ntub.imd.birc.firstmvc.bean.MemberBean;

public interface MemberService extends BaseService<MemberBean, String> {
}
