package tw.edu.ntub.imd.birc.firstmvc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstMvcApplicationTests {

    @Test
    void contextLoads() {
    }

}
